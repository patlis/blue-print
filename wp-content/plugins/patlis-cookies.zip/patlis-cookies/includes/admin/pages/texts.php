<?php
if (!defined('ABSPATH')) exit;

/**
 * Patlis Cookies – Admin Page: Texts
 *
 * Option name: patlis_cookies_texts
 * Settings group: patlis_cookies_texts_group
 */

/**
 * Default texts (standalone όπως στο screenshot).
 */
function patlis_cookies_text_defaults(): array {
    return [
        // Banner
        'title'       => 'This website uses cookies',
        'description' => 'We use cookies to personalise content and ads, to provide social media features and to analyse traffic on our website. We also share information about your use of our website with our social media, advertising and analytics partners. Our partners may combine this information with other data you have provided to them or that they have collected as part of your use of the services.',

        // Buttons
        'btn_allow_all'      => 'Allow All Cookies',
        'btn_only_necessary' => 'Only necessary Cookies',
        'btn_save_close'     => 'Aply and Close',
        'btn_customize'      => 'Cookie Settings',
        'more_label' => 'More...',

        // Category descriptions
        'cat_necessary'    => 'Necessary cookies help make a website usable by enabling basic functions such as page navigation and access to secure areas of the website. The website cannot function properly without these cookies.',
        'cat_statistics'   => 'Marketing cookies are used to track visitors across websites. The intention is to display ads that are relevant and engaging for the individual user and therefore more valuable for publishers and third-party advertisers.',
        'cat_marketing'    => 'Marketing cookies are used to track visitors across websites. The intention is to display ads that are relevant and engaging for the individual user and therefore more valuable for publishers and third-party advertisers.',
        'cat_preferences'  => 'Preference cookies enable a website to remember information that changes the way the website behaves or looks, such as your preferred language or the region you are in.',
        'cat_unclassified' => 'Unclassified cookies are cookies that we are currently in the process of classifying, together with the providers of individual cookies.',
    ];
}

function patlis_cookies_sanitize_texts($input): array {

    $defaults = patlis_cookies_text_defaults();
    $out      = $defaults;

    if (!is_array($input)) {
        return $out;
    }

    // Banner
    if (array_key_exists('title', $input)) {
        $out['title'] = sanitize_text_field($input['title']);
    }
    if (array_key_exists('description', $input)) {
        $out['description'] = sanitize_textarea_field($input['description']);
    }

    // Buttons
    if (array_key_exists('btn_allow_all', $input)) {
        $out['btn_allow_all'] = sanitize_text_field($input['btn_allow_all']);
    }
    if (array_key_exists('btn_only_necessary', $input)) {
        $out['btn_only_necessary'] = sanitize_text_field($input['btn_only_necessary']);
    }
    if (array_key_exists('btn_save_close', $input)) {
        $out['btn_save_close'] = sanitize_text_field($input['btn_save_close']);
    }
    if (array_key_exists('btn_customize', $input)) {
        $out['btn_customize'] = sanitize_text_field($input['btn_customize']);
    }
    if (array_key_exists('more_label', $input)) {
        $out['more_label'] = sanitize_text_field($input['more_label']);
    }

    // Category descriptions
    if (array_key_exists('cat_necessary', $input)) {
        $out['cat_necessary'] = sanitize_textarea_field($input['cat_necessary']);
    }
    if (array_key_exists('cat_statistics', $input)) {
        $out['cat_statistics'] = sanitize_textarea_field($input['cat_statistics']);
    }
    if (array_key_exists('cat_marketing', $input)) {
        $out['cat_marketing'] = sanitize_textarea_field($input['cat_marketing']);
    }
    if (array_key_exists('cat_preferences', $input)) {
        $out['cat_preferences'] = sanitize_textarea_field($input['cat_preferences']);
    }
    if (array_key_exists('cat_unclassified', $input)) {
        $out['cat_unclassified'] = sanitize_textarea_field($input['cat_unclassified']);
    }

    return $out;
}


/**
 * Render page callback (called from your menu.php).
 */
function patlis_cookies_render_texts_page() {
    if (!current_user_can('patlis_manage')) return;

    $defaults = patlis_cookies_text_defaults();
    $t        = wp_parse_args(get_option('patlis_cookies_texts', []), $defaults);

    $val = function (string $key) use ($t, $defaults) {
        return isset($t[$key]) ? $t[$key] : ($defaults[$key] ?? '');
    };
        echo '<style>
       .form-table th,
       .form-table td {
        padding-top: 5px;
        padding-bottom: 0px;
      }
    
  </style>';
  
    echo '<div class="wrap">';
    echo '<h1>Patlis Cookies – Texts</h1>';
    if (!empty($_GET['patlis_saved'])) echo '<div class="notice notice-success is-dismissible"><p>Saved.</p></div>';

    echo '<form method="post" action="'. esc_url(admin_url('admin-post.php')) .'">';
    echo '<input type="hidden" name="action" value="patlis_cookies_save_texts">';
    wp_nonce_field('patlis_cookies_save_texts');

    echo '<table class="form-table" role="presentation">';

    echo '<tr><th scope="row">Banner title</th><td>';
    echo '<input type="text" class="regular-text" name="patlis_cookies_texts[title]" value="' . esc_attr($val('title')) . '">';
    echo '</td></tr>';

    echo '<tr><th scope="row">Banner description</th><td>';
    echo '<textarea class="large-text" rows="5" name="patlis_cookies_texts[description]">' . esc_textarea($val('description')) . '</textarea>';
    echo '</td></tr>';

    echo '<tr><th scope="row">Btn: Allow all:</th><td>';
    echo '<input type="text" class="regular-text" name="patlis_cookies_texts[btn_allow_all]" value="' . esc_attr($val('btn_allow_all')) . '">';
    echo '</td></tr>';

    echo '<tr><th scope="row">Btn: Only necessary:</th><td>';
    echo '<input type="text" class="regular-text" name="patlis_cookies_texts[btn_only_necessary]" value="' . esc_attr($val('btn_only_necessary')) . '">';
    echo '</td></tr>';

    echo '<tr><th scope="row">Btn: Save & close:</th><td>';
    echo '<input type="text" class="regular-text" name="patlis_cookies_texts[btn_save_close]" value="' . esc_attr($val('btn_save_close')) . '">';
    echo '</td></tr>';

    echo '<tr><th scope="row">Btn: Customize:</th><td>';
    echo '<input type="text" class="regular-text" name="patlis_cookies_texts[btn_customize]" value="' . esc_attr($val('btn_customize')) . '">';
    echo '</td></tr>';

    echo '<tr><th scope="row">Btn: More..:</th><td>';
    echo '<input type="text" class="regular-text" name="patlis_cookies_texts[more_label]" value="' . esc_attr($val('more_label')) . '">';
    echo '</td></tr>';    
    

    echo '<tr><th scope="row">Category descriptions</th><td>';

    echo '<p><strong>Necessary</strong><br>';
    echo '<textarea class="large-text" rows="3" name="patlis_cookies_texts[cat_necessary]">' . esc_textarea($val('cat_necessary')) . '</textarea></p>';

    echo '<p><strong>Statistics</strong><br>';
    echo '<textarea class="large-text" rows="3" name="patlis_cookies_texts[cat_statistics]">' . esc_textarea($val('cat_statistics')) . '</textarea></p>';

    echo '<p><strong>Marketing</strong><br>';
    echo '<textarea class="large-text" rows="3" name="patlis_cookies_texts[cat_marketing]">' . esc_textarea($val('cat_marketing')) . '</textarea></p>';

    echo '<p><strong>Preferences</strong><br>';
    echo '<textarea class="large-text" rows="3" name="patlis_cookies_texts[cat_preferences]">' . esc_textarea($val('cat_preferences')) . '</textarea></p>';

    echo '<p><strong>Unclassified</strong><br>';
    echo '<textarea class="large-text" rows="3" name="patlis_cookies_texts[cat_unclassified]">' . esc_textarea($val('cat_unclassified')) . '</textarea></p>';

    echo '</td></tr>';

    echo '</table>';

    submit_button('Save changes');
    echo '</form>';

    echo '</div>';
}
