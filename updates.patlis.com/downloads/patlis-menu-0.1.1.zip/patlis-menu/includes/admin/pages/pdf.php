<?php
if (!defined('ABSPATH')) exit;

final class Patlis_Menu_Admin_Page_Pdf
{
    public const OPTION_NAME = 'patlis_menu_pdf';

    public static function get_options(): array
    {
        $opt = get_option(self::OPTION_NAME, []);
        return is_array($opt) ? $opt : [];
    }

    public static function sanitize($input): array
    {
        $in = is_array($input) ? $input : [];

        return [
            'name'     => isset($in['name']) ? sanitize_text_field((string) $in['name']) : '',
            'file_id'  => isset($in['file_id']) ? max(0, (int) $in['file_id']) : 0,
            'file_url' => isset($in['file_url']) ? esc_url_raw((string) $in['file_url']) : '',
        ];
    }

    public static function render(): void
    {
        if (!current_user_can('patlis_manage')) return;

        $opt = self::get_options();
        $file_id  = isset($opt['file_id']) ? (int) $opt['file_id'] : 0;
        $file_url = isset($opt['file_url']) ? (string) $opt['file_url'] : '';
        $name     = isset($opt['name']) ? (string) $opt['name'] : '';

        wp_enqueue_media();
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Menu – PDF', 'patlis-menu'); ?></h1>

            <?php if (!empty($_GET['patlis_saved'])): ?>
                <div class="notice notice-success is-dismissible"><p>Saved.</p></div>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="patlis_menu_save_pdf">
                <?php wp_nonce_field('patlis_menu_save_pdf'); ?>

                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="patlis_menu_pdf_name"><?php esc_html_e('Name', 'patlis-menu'); ?></label></th>
                        <td>
                            <input id="patlis_menu_pdf_name"
                                   type="text"
                                   class="regular-text"
                                   name="<?php echo esc_attr(self::OPTION_NAME); ?>[name]"
                                   value="<?php echo esc_attr($name); ?>"
                                   placeholder="<?php echo esc_attr__('Wine menu', 'patlis-menu'); ?>">
                            <p class="description"><?php esc_html_e('Example: Wine menu', 'patlis-menu'); ?></p>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row"><label><?php esc_html_e('PDF file', 'patlis-menu'); ?></label></th>
                        <td>
                            <input type="hidden"
                                   id="patlis_menu_pdf_file_id"
                                   name="<?php echo esc_attr(self::OPTION_NAME); ?>[file_id]"
                                   value="<?php echo esc_attr($file_id); ?>">

                            <input type="url"
                                   id="patlis_menu_pdf_file_url"
                                   class="regular-text"
                                   name="<?php echo esc_attr(self::OPTION_NAME); ?>[file_url]"
                                   value="<?php echo esc_attr($file_url); ?>"
                                   placeholder="https://example.com/file.pdf">

                            <p style="margin-top:8px;">
                                <button type="button" class="button" id="patlis_menu_pdf_select"><?php esc_html_e('Select PDF', 'patlis-menu'); ?></button>
                                <button type="button" class="button" id="patlis_menu_pdf_remove"<?php echo $file_url !== '' ? '' : ' style="display:none;"'; ?>><?php esc_html_e('Remove', 'patlis-menu'); ?></button>
                            </p>
                            <p class="description"><?php esc_html_e('Select or paste the PDF file URL.', 'patlis-menu'); ?></p>
                        </td>
                    </tr>
                </table>

                <?php submit_button(__('Save', 'patlis-menu')); ?>
            </form>
        </div>

        <script>
        document.addEventListener('DOMContentLoaded', function () {
            var frame = null;
            var selectBtn = document.getElementById('patlis_menu_pdf_select');
            var removeBtn = document.getElementById('patlis_menu_pdf_remove');
            var fileIdInput = document.getElementById('patlis_menu_pdf_file_id');
            var fileUrlInput = document.getElementById('patlis_menu_pdf_file_url');

            function updateRemoveButton() {
                if (!removeBtn || !fileUrlInput) return;
                removeBtn.style.display = fileUrlInput.value ? '' : 'none';
            }

            if (selectBtn) {
                selectBtn.addEventListener('click', function (event) {
                    event.preventDefault();

                    if (frame) {
                        frame.open();
                        return;
                    }

                    frame = wp.media({
                        title: 'Select PDF',
                        button: { text: 'Use this PDF' },
                        library: { type: 'application/pdf' },
                        multiple: false
                    });

                    frame.on('select', function () {
                        var file = frame.state().get('selection').first().toJSON();
                        if (fileIdInput) fileIdInput.value = file.id || '';
                        if (fileUrlInput) fileUrlInput.value = file.url || '';
                        updateRemoveButton();
                    });

                    frame.open();
                });
            }

            if (removeBtn) {
                removeBtn.addEventListener('click', function (event) {
                    event.preventDefault();
                    if (fileIdInput) fileIdInput.value = '';
                    if (fileUrlInput) fileUrlInput.value = '';
                    updateRemoveButton();
                });
            }

            if (fileUrlInput) {
                fileUrlInput.addEventListener('input', updateRemoveButton);
            }

            updateRemoveButton();
        });
        </script>
        <?php
    }
}
