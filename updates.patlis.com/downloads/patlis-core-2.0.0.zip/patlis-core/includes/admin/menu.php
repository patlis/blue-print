<?php
if (!defined('ABSPATH')) exit;

final class Patlis_Admin_Menu {

  public static function register(): void {
      $capability  = 'patlis_manage';

    add_menu_page(
      __('Site settings', 'patlis-core'),
      __('Site settings', 'patlis-core'),
      $capability,
      'patlis-basic',
      ['Patlis_Admin_Page_Basic', 'render'],
      'dashicons-admin-generic',
     26
    );

    add_submenu_page(
      'patlis-basic',
      __('Basic settings', 'patlis-core'),
      __('Basic settings', 'patlis-core'),
      $capability,
      'patlis-basic',
      ['Patlis_Admin_Page_Basic', 'render']
    );
    
    add_submenu_page(
      'patlis-basic',
      __('Social media', 'patlis-core'),
      __('Social media', 'patlis-core'),
      $capability,
      'patlis-social',
      ['Patlis_Admin_Page_Social', 'render']
    );

    add_submenu_page(
      'patlis-basic',
      __('Opening times', 'patlis-core'),
      __('Opening times', 'patlis-core'),
      $capability,
      'patlis-opening',
      ['Patlis_Admin_Page_Opening', 'render']
    );
    
    add_submenu_page(
      'patlis-basic',
      __('Center Popup', 'patlis-core'),
      __('Center Popup', 'patlis-core'),
      $capability,
      'patlis-center-popup',
      ['Patlis_Admin_Page_Center_Popup', 'render']
    );
    
    add_submenu_page(
      'patlis-basic',
      __('Notification Bar', 'patlis-core'),
      __('Notification Bar', 'patlis-core'),
      $capability,
      'patlis-notification-bar',
      ['Patlis_Admin_Page_Notification_Bar', 'render']
    );
    
    add_submenu_page(
      'patlis-basic',
      __('Translations', 'patlis-core'),
      __('Translations', 'patlis-core'),
      $capability,
      'patlis-translations',
      ['Patlis_Admin_Page_Translations', 'render']
    );

    add_submenu_page(
      'patlis-basic',
      __('Home page', 'patlis-core'),
      __('Home page', 'patlis-core'),
      $capability,
      'patlis-homepage',
      ['Patlis_Admin_Page_Homepage', 'render']
    );

    /* ------------- Administrator only ------------------ */
    add_submenu_page(
      'patlis-basic',
      'Instance Tools',
      'Instance Tools',
      'manage_options',
      'patlis-instance-tools',
      ['Patlis_Admin_Page_Instance_Tools', 'render']
    );

    add_submenu_page(
      'patlis-basic',
      'White label settings',
      'White label settings',
      'manage_options',
      'patlis-white-label',
      ['Patlis_Admin_Page_White_Label', 'render']
    );

    add_submenu_page(
      'patlis-basic',
      'Languages Visibility',
      'Languages',
      'manage_options',
      'patlis-languages-visibility',
      'patlis_render_languages_visibility_page'
    );

    
  }
}
