<?php
if (!defined('ABSPATH')) {
    exit;
}

final class Patlis_Admin_Page_Instance_Tools
{
    private static function count_post_types(array $post_types): int
    {
        global $wpdb;

        $post_types = array_values(array_filter(array_map('sanitize_key', $post_types)));
        if ($post_types === []) {
            return 0;
        }

        $placeholders = implode(',', array_fill(0, count($post_types), '%s'));
        $sql = "
            SELECT COUNT(1)
            FROM {$wpdb->posts}
            WHERE post_type IN ({$placeholders})
              AND post_status <> 'auto-draft'
        ";

        $count = $wpdb->get_var($wpdb->prepare($sql, ...$post_types));

        return max(0, (int) $count);
    }

    private static function count_taxonomy_terms(string $taxonomy): int
    {
        global $wpdb;

        $taxonomy = sanitize_key($taxonomy);
        if ($taxonomy === '') {
            return 0;
        }

        $sql = "SELECT COUNT(1) FROM {$wpdb->term_taxonomy} WHERE taxonomy = %s";
        $count = $wpdb->get_var($wpdb->prepare($sql, $taxonomy));

        return max(0, (int) $count);
    }

    private static function table_exists(string $table_name): bool
    {
        global $wpdb;

        $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table_name));

        return is_string($found) && $found === $table_name;
    }

    private static function count_table_rows(string $table_suffix): int
    {
        global $wpdb;

        $table_suffix = preg_replace('/[^a-z0-9_]/', '', strtolower($table_suffix));
        if (!is_string($table_suffix) || $table_suffix === '') {
            return 0;
        }

        $table_name = $wpdb->prefix . $table_suffix;
        if (!self::table_exists($table_name)) {
            return 0;
        }

        $sql = "SELECT COUNT(1) FROM {$table_name}";
        $count = $wpdb->get_var($sql);

        return max(0, (int) $count);
    }

    private static function definition(): array
    {
        return [
            'Menu' => [
                [
                    'label'  => 'Delete menu categories',
                    'count'  => self::count_taxonomy_terms('menu_section'),
                    'action' => 'delete_menu_categories',
                ],
                [
                    'label'  => 'Delete menu items',
                    'count'  => self::count_post_types(['menu_item']),
                    'action' => 'delete_menu_items',
                ],
                [
                    'label'  => 'Delete menu Pdfs',
                    'count'  => self::count_post_types(['menu_pdf']),
                    'action' => 'delete_menu_pdfs',
                ],
            ],
            'Leads' => [
                [
                    'label'  => 'Delete Leads',
                    'count'  => self::count_table_rows('patlis_leads'),
                    'action' => 'delete_table_patlis_leads',
                ],
                [
                    'label'  => 'Delete Contacts',
                    'count'  => self::count_table_rows('patlis_contacts'),
                    'action' => 'delete_table_patlis_contacts',
                ],
                [
                    'label'  => 'Delete Reservations',
                    'count'  => self::count_table_rows('patlis_reservations'),
                    'action' => 'delete_table_patlis_reservations',
                ],
                [
                    'label'  => 'Delete Bookings',
                    'count'  => self::count_table_rows('patlis_bookings'),
                    'action' => 'delete_table_patlis_bookings',
                ],
            ],
            'Content' => [
                [
                    'label'  => 'Delete Slides',
                    'count'  => self::count_post_types(['slide']),
                    'action' => 'delete_slides',
                ],
                [
                    'label'  => 'Delete Services',
                    'count'  => self::count_post_types(['services', 'service']),
                    'action' => 'delete_services',
                ],
                [
                    'label'  => 'Delete Events',
                    'count'  => self::count_post_types(['events', 'event']),
                    'action' => 'delete_events',
                ],
                [
                    'label'  => 'Delete Galley',
                    'count'  => self::count_post_types(['patlis_gallery', 'gallery']),
                    'action' => 'delete_gallery',
                ],
                [
                    'label'  => 'Delete Reviews',
                    'count'  => self::count_post_types(['reviews', 'review']),
                    'action' => 'delete_reviews',
                ],
                [
                    'label'  => 'Delete Timelines (for about us)',
                    'count'  => self::count_post_types(['timeline_item', 'timelines', 'timeline']),
                    'action' => 'delete_timelines',
                ],
            ],
            'Kiosk Mode' => [
                [
                    'label'  => 'Delete Kiosk slides',
                    'count'  => self::count_post_types(['kiosk_slide']),
                    'action' => 'delete_kiosk_slides',
                ],
            ],
            'Accommodation' => [
                [
                    'label'  => 'Delete rooms',
                    'count'  => self::count_post_types(['patlis_room', 'room']),
                    'action' => 'delete_rooms',
                ],
                [
                    'label'  => 'Delete offers & Packages',
                    'count'  => self::count_post_types(['rates']),
                    'action' => 'delete_offers_packages',
                ],
                [
                    'label'  => 'Delete Property Facilities',
                    'count'  => self::count_taxonomy_terms('property_facility'),
                    'action' => 'delete_property_facilities',
                ],
                [
                    'label'  => 'Delete Property Services',
                    'count'  => self::count_taxonomy_terms('property_service'),
                    'action' => 'delete_property_services',
                ],
                [
                    'label'  => 'Delete Room Amenities',
                    'count'  => self::count_taxonomy_terms('room_amenity'),
                    'action' => 'delete_room_amenities',
                ],
                [
                    'label'  => 'Delete Meal Plans',
                    'count'  => self::count_post_types(['patlis_meal_plan']),
                    'action' => 'delete_meal_plans',
                ],
                [
                    'label'  => 'Delete Experiences',
                    'count'  => self::count_post_types(['experience']),
                    'action' => 'delete_experiences',
                ],
                [
                    'label'  => 'Delete Rate Periods',
                    'count'  => self::count_post_types(['hotel_rate_periods']),
                    'action' => 'delete_rate_periods',
                ],
                [
                    'label'  => 'Delete Room Rates',
                    'count'  => self::count_post_types(['patlis_room_rate']),
                    'action' => 'delete_room_rates',
                ],
            ],
        ];
    }

    public static function render(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die('Not allowed.');
        }

        $sections = self::definition();
        $nonce    = wp_create_nonce('patlis_instance_tool');
        ?>
        
            <style>
                .patlis-instance-tools-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
                    gap: 16px;
                    margin-top: 16px;
                }

                .patlis-instance-tools-card {
                    background: #fff;
                    border: 1px solid #dcdcde;
                    border-radius: 8px;
                    padding: 14px;
                }

                .patlis-instance-tools-card h2 {
                    margin: 0 0 10px;
                    font-size: 16px;
                }

                .patlis-instance-tools-list {
                    display: grid;
                    gap: 8px;
                }

                .patlis-instance-tool-button {
                    width: 100%;
                    text-align: left;
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                }

                .patlis-instance-tool-badge {
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    min-width: 26px;
                    height: 22px;
                    padding: 0 8px;
                    border-radius: 999px;
                    background: #f0f0f1;
                    color: #1d2327;
                    font-weight: 600;
                    font-size: 12px;
                }

                .patlis-instance-tool-live {
                    border-color: #cc1818 !important;
                    color: #cc1818 !important;
                }

                .patlis-instance-tool-live:hover {
                    background: #cc1818 !important;
                    color: #fff !important;
                    border-color: #cc1818 !important;
                }

                .patlis-instance-tool-running {
                    opacity: 0.6;
                    cursor: wait !important;
                    pointer-events: none;
                }
            </style>
        <div class="wrap">
            <h1><?php esc_html_e('Instance Tools', 'patlis-core'); ?></h1>

            <h2>Steps for Installation: </h2>
            <h3>aapanel</h3>
            <ol>
                <li>Wp Toolkit > Select site > Config > Config file > Copy the configuration file from dev (replace the dev.patlis.com with the appropriate domain)</li>
                <li>Files > /www/wwwroot/site-domain > wp-config.php > Set: <b style="color: red;">PATLIS_VERSION</b></li>
            </ol>
            
            <h3>Bricks</h3>
            <ol>
                <li>Settings > Custom code > Regenerate code signatures</li>
                <li>Settings > Performance > Regenerate CSS files"</li>
            </ol>

            <h3>WordPress settings</h3>
            <ol>
                <li>Settings > General Settings > set: Site Title & Tagline</li>                
                <li>Settings > General Settings > set: WordPress Address (URL) & Site Address (URL)</li>
                <li>Settings > General Settings > Set: Time zone</li>
                <li>Plugin Languages > Set: default language</li>
                <li>Settings > Permalinks > Save (to flush rewrite rules)</li>  
                <li>Plugin WP Mail SMTP: SMTP Username & Password</li>
                <li>Appearance > Menus: Create the main menu with the required structure</li>
                <li>Settings > MainWP Child: configure the child settings</li>
                <li>Users > Add new: Create a user with <b style="color: red;">Site Owner</b> role for the client (and share credentials)</li>
            </ol>
            
            <h3>Theme settings</h3>
            <ol>
                <li>Plugin Site settings >  Fill all the required fields</li>
                <li>Plugin Site settings > Languages: Set Languages Visibility (only 2 by default)</li>
                <li>Plugin Cookies: Set Google Tag Manager ID & GA4 if existing</li> 
                <li>Plugin Reservations: Set the reservation settings (Gastro & Dining Version)</li> 
                <li>Plugin Accommodation > Settings: Set the accommodation settings (Hotel version)</li>
                <li>Plugin Kiosk Mode: Set the kiosk mode settings (kiosk version)</li>
            </ol>


            <h2 style="margin-top: 4em;">Database Cleanup Tools</h2>

            <div class="patlis-instance-tools-grid">
                <?php foreach ($sections as $section_title => $actions) : ?>
                    <section class="patlis-instance-tools-card">
                        <h2><?php echo esc_html($section_title); ?></h2>

                        <div class="patlis-instance-tools-list">
                            <?php foreach ($actions as $action) :
                                $is_live = !empty($action['action']);
                            ?>
                                <button
                                    type="button"
                                    class="button patlis-instance-tool-button<?php echo $is_live ? ' patlis-instance-tool-live' : ''; ?>"
                                    <?php echo $is_live ? '' : 'disabled'; ?>
                                    <?php if ($is_live) : ?>
                                        data-action="<?php echo esc_attr($action['action']); ?>"
                                        data-label="<?php echo esc_attr($action['label'] ?? ''); ?>"
                                        data-count="<?php echo (int) ($action['count'] ?? 0); ?>"
                                    <?php endif; ?>
                                >
                                    <span><?php echo esc_html((string) ($action['label'] ?? '')); ?></span>
                                    <span class="patlis-instance-tool-badge"><?php echo esc_html((string) ((int) ($action['count'] ?? 0))); ?></span>
                                </button>
                            <?php endforeach; ?>
                        </div>
                    </section>
                <?php endforeach; ?>
            </div>

            <script>
            (function () {
                var ajaxUrl = <?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>;
                var nonce   = <?php echo wp_json_encode($nonce); ?>;

                document.querySelectorAll('.patlis-instance-tool-live').forEach(function (btn) {
                    btn.addEventListener('click', function () {
                        var label  = btn.dataset.label  || btn.innerText.trim();
                        var count  = btn.dataset.count  || '?';
                        var action = btn.dataset.action;

                        var msg = 'Are you sure you want to run:\n"' + label + '"?\n\n' +
                                  'This will permanently delete ' + count + ' item(s).\n' +
                                  'This cannot be undone.';

                        if (!window.confirm(msg)) {
                            return;
                        }

                        btn.disabled = true;
                        btn.classList.add('patlis-instance-tool-running');

                        var formData = new FormData();
                        formData.append('action',      'patlis_instance_tool');
                        formData.append('nonce',       nonce);
                        formData.append('tool_action', action);

                        fetch(ajaxUrl, {
                            method:      'POST',
                            credentials: 'same-origin',
                            body:        formData,
                        })
                        .then(function (r) { return r.json(); })
                        .then(function (data) {
                            btn.classList.remove('patlis-instance-tool-running');
                            if (data.success) {
                                alert(data.data.message);
                                window.location.reload();
                            } else {
                                var errMsg = (data.data && data.data.message) ? data.data.message : 'Unknown error.';
                                alert('Error: ' + errMsg);
                                btn.disabled = false;
                            }
                        })
                        .catch(function () {
                            btn.classList.remove('patlis-instance-tool-running');
                            alert('Request failed. Please try again.');
                            btn.disabled = false;
                        });
                    });
                });
            }());
            </script>
        </div>
        <?php
    }

    public static function handle_ajax(): void
    {
        check_ajax_referer('patlis_instance_tool', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Not allowed.'], 403);
        }

        $tool_action = isset($_POST['tool_action']) ? sanitize_key((string) $_POST['tool_action']) : '';

        switch ($tool_action) {
            case 'delete_menu_categories':      $message = self::do_delete_taxonomy_terms('menu_section'); break;
            case 'delete_menu_items':           $message = self::do_delete_post_types(['menu_item']); break;
            case 'delete_menu_pdfs':            $message = self::do_delete_post_types(['menu_pdf']); break;
            case 'delete_table_patlis_leads':   $message = self::do_truncate_table('patlis_leads'); break;
            case 'delete_table_patlis_contacts':$message = self::do_truncate_table('patlis_contacts'); break;
            case 'delete_table_patlis_reservations': $message = self::do_truncate_table('patlis_reservations'); break;
            case 'delete_table_patlis_bookings':$message = self::do_truncate_table('patlis_bookings'); break;
            case 'delete_services':             $message = self::do_delete_post_types(['services', 'service']); break;
            case 'delete_slides':               $message = self::do_delete_post_types(['slide']); break;
            case 'delete_events':               $message = self::do_delete_post_types(['events', 'event']); break;
            case 'delete_gallery':              $message = self::do_delete_post_types(['patlis_gallery', 'gallery']); break;
            case 'delete_reviews':              $message = self::do_delete_post_types(['reviews', 'review']); break;
            case 'delete_timelines':            $message = self::do_delete_post_types(['timeline_item', 'timelines', 'timeline']); break;
            case 'delete_kiosk_slides':         $message = self::do_delete_post_types(['kiosk_slide']); break;
            case 'delete_rooms':                $message = self::do_delete_post_types(['patlis_room', 'room']); break;
            case 'delete_offers_packages':      $message = self::do_delete_post_types(['rates']); break;
            case 'delete_property_facilities':  $message = self::do_delete_taxonomy_terms('property_facility'); break;
            case 'delete_property_services':    $message = self::do_delete_taxonomy_terms('property_service'); break;
            case 'delete_room_amenities':       $message = self::do_delete_taxonomy_terms('room_amenity'); break;
            case 'delete_meal_plans':           $message = self::do_delete_post_types(['patlis_meal_plan']); break;
            case 'delete_experiences':          $message = self::do_delete_post_types(['experience']); break;
            case 'delete_rate_periods':         $message = self::do_delete_post_types(['hotel_rate_periods']); break;
            case 'delete_room_rates':           $message = self::do_delete_post_types(['patlis_room_rate']); break;
            default:
                wp_send_json_error(['message' => 'Unknown action.'], 400);
                return;
        }

        wp_send_json_success(['message' => $message]);
    }

    private static function do_truncate_table(string $table_suffix): string
    {
        global $wpdb;

        $table_suffix = preg_replace('/[^a-z0-9_]/', '', strtolower($table_suffix));
        $table_name   = $wpdb->prefix . $table_suffix;

        if (!self::table_exists($table_name)) {
            return 'Table not found: ' . $table_name;
        }

        $count  = (int) $wpdb->get_var("SELECT COUNT(1) FROM {$table_name}");
        $wpdb->query("DELETE FROM {$table_name}");

        return sprintf('Deleted %d row(s) from %s.', $count, $table_suffix);
    }

    private static function do_delete_post_types(array $post_types): string
    {
        $deleted = 0;
        foreach ($post_types as $post_type) {
            $post_type = sanitize_key($post_type);
            $ids = get_posts([
                'post_type'      => $post_type,
                'post_status'    => 'any',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'lang'           => '',
            ]);
            foreach ($ids as $id) {
                if (wp_delete_post((int) $id, true)) $deleted++;
            }
        }
        return sprintf('Deleted %d item(s).', $deleted);
    }

    private static function do_delete_taxonomy_terms(string $taxonomy): string
    {
        global $wpdb;

        $taxonomy = sanitize_key($taxonomy);

        // Direct SQL to bypass Polylang language filtering
        $term_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT term_id FROM {$wpdb->term_taxonomy} WHERE taxonomy = %s",
            $taxonomy
        ));

        $deleted = 0;
        foreach ($term_ids as $term_id) {
            if (!is_wp_error(wp_delete_term((int) $term_id, $taxonomy))) $deleted++;
        }
        return sprintf('Deleted %d term(s) from %s.', $deleted, $taxonomy);
    }

    private static function do_delete_post_type(string $post_type): string
    {
        $post_type = sanitize_key($post_type);

        $ids = get_posts([
            'post_type'      => $post_type,
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'lang'           => '',   // Polylang: bypass language filter, return all languages
        ]);

        $deleted = 0;
        foreach ($ids as $id) {
            if (wp_delete_post((int) $id, true)) {
                $deleted++;
            }
        }

        return sprintf('Deleted %d %s item(s).', $deleted, $post_type);
    }
}

add_action('wp_ajax_patlis_instance_tool', [Patlis_Admin_Page_Instance_Tools::class, 'handle_ajax']);
