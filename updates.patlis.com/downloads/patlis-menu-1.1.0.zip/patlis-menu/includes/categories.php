<?php
if (!defined('ABSPATH')) exit;

/**
 * Term meta fields for taxonomy: menu_section (Menu Categories)
 *
 * Meta keys (Option B – categories = pmc_*)
 *  - pmc_show (0/1)
 *  - pmc_sort (int)
 *  - pmc_image_id (attachment id)
 *  - pmc_day0a..pmc_day6b (HH:MM)
 *
 * Day mapping:
 *  day0 = Sunday ... day6 = Saturday
 * Rule:
 *  if from/to empty => visible all day
 */

/* ------------------------------------------------------------
 * Admin assets (Media uploader) only on menu_section screens
 * ------------------------------------------------------------ */
add_action('admin_enqueue_scripts', 'patlis_menu_section_admin_assets');
function patlis_menu_section_admin_assets(string $hook): void
{
    if ($hook !== 'edit-tags.php' && $hook !== 'term.php') return;
    if (!function_exists('get_current_screen')) return;

    $screen = get_current_screen();
    if (!$screen || ($screen->taxonomy ?? '') !== 'menu_section') return;

    wp_enqueue_media();
    wp_enqueue_script('jquery-ui-sortable');

    $select_category_image = wp_json_encode(__('Select category image', 'patlis-menu'));
    $use_this_image = wp_json_encode(__('Use this image', 'patlis-menu'));

    // Use a tiny inline script; jQuery is available in WP admin.
    $js = <<<JS
jQuery(function($){
  var frame = null;

  function clearImage(){
    $('#pmc_image_id').val('');
    $('#pmc_image_preview').html('');
    $('#pmc_image_remove').hide();
  }

  function setImage(att){
    var id  = att.id || '';
    var url = (att.sizes && att.sizes.thumbnail) ? att.sizes.thumbnail.url : att.url;
    $('#pmc_image_id').val(id);
    $('#pmc_image_preview').html('<img src="'+url+'" style="max-width:120px;height:auto;border:1px solid #ddd;padding:2px;background:#fff;" />');
    $('#pmc_image_remove').show();
  }

  $(document).on('click', '#pmc_image_select', function(e){
    e.preventDefault();

    if (frame) { frame.open(); return; }

    frame = wp.media({
            title: {$select_category_image},
            button: { text: {$use_this_image} },
      multiple: false
    });

    frame.on('select', function(){
      var att = frame.state().get('selection').first().toJSON();
      setImage(att);
    });

    frame.open();
  });

  $(document).on('click', '#pmc_image_remove', function(e){
    e.preventDefault();
    clearImage();
  });

  if ($('#pmc_image_id').val()) $('#pmc_image_remove').show();
  else $('#pmc_image_remove').hide();
});
JS;

    wp_add_inline_script('jquery', $js);

    if ($hook === 'edit-tags.php') {
        $nonce    = wp_create_nonce('patlis_menu_section_sort_nonce');
        $ajax_url = esc_url(admin_url('admin-ajax.php'));
        $drag_to_reorder = esc_js(__('Drag to reorder', 'patlis-menu'));
        $sort_js  = 'var patlisMcSort={nonce:"' . esc_js($nonce) . '",ajaxurl:"' . esc_js($ajax_url) . '"};' . "\n";
        $sort_js .= 'jQuery(function($){' . "\n";
        $sort_js .= '    var $list=$("#the-list");' . "\n";
        $sort_js .= '    if(!$list.length)return;' . "\n";
        $sort_js .= '    $("<style>.column-pmc_sort{width:48px}#the-list .patlis-sort-ph{background:#f0f6fc;height:44px;}</style>").appendTo("head");' . "\n";
        $sort_js .= '    $list.find("tr").each(function(){$(this).find("td.column-pmc_sort").prepend("<span class=\'patlis-drag-handle dashicons dashicons-menu\' style=\'cursor:move;margin-right:8px;color:#aaa;vertical-align:middle;font-size:24px;padding:8px;display:inline-block;\' title=\'' . $drag_to_reorder . '\'></span>");});' . "\n";
        $sort_js .= '    $list.sortable({items:"tr",handle:".patlis-drag-handle",axis:"y",opacity:.7,placeholder:"patlis-sort-ph",update:function(){' . "\n";
        $sort_js .= '        var ids=[];$list.find("tr").each(function(){var m=$(this).attr("id");if(m&&m.indexOf("tag-")===0)ids.push(m.replace("tag-",""));});' . "\n";
        $sort_js .= '        $.post(patlisMcSort.ajaxurl,{action:"patlis_menu_section_sort",nonce:patlisMcSort.nonce,ids:ids});' . "\n";
        $sort_js .= '    }});' . "\n";
        $sort_js .= '});';
        // Touch Punch: maps touch events to mouse events for jQuery UI Sortable on mobile.
        $touch_punch = '(function(a){function f(a,b){if(!(a.originalEvent.touches.length>1)){a.preventDefault();var c=a.originalEvent.changedTouches[0],d=document.createEvent("MouseEvents");d.initMouseEvent(b,!0,!0,window,1,c.screenX,c.screenY,c.clientX,c.clientY,!1,!1,!1,!1,0,null),a.target.dispatchEvent(d)}}if(a.support.touch="ontouchend"in document,a.support.touch){var e,b=a.ui.mouse.prototype,c=b._mouseInit,g=b._mouseDestroy;b._touchStart=function(a){var b=this;!e&&b._mouseCapture(a.originalEvent.changedTouches[0])&&(e=!0,b._touchMoved=!1,f(a,"mouseover"),f(a,"mousemove"),f(a,"mousedown"))},b._touchMove=function(a){e&&(b._touchMoved=!0,f(a,"mousemove"))},b._touchEnd=function(a){e&&(f(a,"mouseup"),f(a,"mouseout"),b._touchMoved||f(a,"click"),e=!1)},b._mouseInit=function(){var b=this;b.element.bind("touchstart",a.proxy(b._touchStart,b)).bind("touchmove",a.proxy(b._touchMove,b)).bind("touchend",a.proxy(b._touchEnd,b)),c.call(b)},b._mouseDestroy=function(){var b=this;b.element.unbind("touchstart",b._touchStart).unbind("touchmove",b._touchMove).unbind("touchend",b._touchEnd),g.call(b)}}}(jQuery));';
        wp_add_inline_script('jquery-ui-sortable', $touch_punch);
        wp_add_inline_script('jquery', $sort_js);
    }
}

/* ------------------------------------------------------------
 * Add form fields
 * ------------------------------------------------------------ */
add_action('menu_section_add_form_fields', 'patlis_menu_section_add_fields');
function patlis_menu_section_add_fields(): void
{
    // Our own nonce for term meta saves
    wp_nonce_field('patlis_menu_section_meta', 'patlis_menu_section_nonce');
     echo '<style>.term-slug-wrap, .column-slug{display:none !important;}</style>';

    ?>
    <div class="form-field" style="display:flex;align-items:center;gap:16px;">
        <label for="pmc_show"><?php esc_html_e('Enabled', 'patlis-menu'); ?></label>
        <input type="checkbox" name="pmc_show" id="pmc_show" value="1" checked>
    </div>

    <div class="form-field" style="margin-top:24px; margin-bottom:24px;">
        <h3><?php esc_html_e('Image', 'patlis-menu'); ?></h3>
        <div id="pmc_image_preview"></div>
        <input type="hidden" name="pmc_image_id" id="pmc_image_id" value="">
        <p>
            <button type="button" class="button" id="pmc_image_select"><?php esc_html_e('Select image', 'patlis-menu'); ?></button>
            <button type="button" class="button" id="pmc_image_remove" style="display:none;"><?php esc_html_e('Remove', 'patlis-menu'); ?></button>
        </p>
    </div>

    <div class="form-field" style="margin-top:36px; margin-bottom:36px;margin-right:24px;">
        <h3><?php esc_html_e('Category visibility schedule', 'patlis-menu'); ?></h3>
        <p class="description"><?php esc_html_e('If both fields are empty, the category is visible all day.', 'patlis-menu'); ?></p>
        <table class="widefat striped">
            <thead>
                <tr>
                    <th><?php esc_html_e('Day', 'patlis-menu'); ?></th>
                    <th><?php esc_html_e('From', 'patlis-menu'); ?></th>
                    <th><?php esc_html_e('To', 'patlis-menu'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php echo patlis_menu_section_schedule_rows(); ?>
            </tbody>
        </table>
    </div>
    <?php
}

/* ------------------------------------------------------------
 * Edit form fields
 * ------------------------------------------------------------ */
add_action('menu_section_edit_form_fields', 'patlis_menu_section_edit_fields');
function patlis_menu_section_edit_fields($term): void
{
    if (!($term instanceof WP_Term)) return;

    echo '<style>.term-slug-wrap{display:none !important;}</style>';

    // Our own nonce for term meta saves
    wp_nonce_field('patlis_menu_section_meta', 'patlis_menu_section_nonce');

    $show = get_term_meta($term->term_id, 'pmc_show', true);
    $show = ($show === '' ? '1' : (string)$show);

    $image_id = (int) get_term_meta($term->term_id, 'pmc_image_id', true);
    $preview  = $image_id ? wp_get_attachment_image($image_id, 'thumbnail', false, [
        'style' => 'max-width:120px;height:auto;border:1px solid #ddd;padding:2px;background:#fff;'
    ]) : '';

    ?>
    <tr class="form-field">
        <th scope="row"><label for="pmc_show"><?php esc_html_e('Show', 'patlis-menu'); ?></label></th>
        <td>
            <label>
                <input type="checkbox" name="pmc_show" id="pmc_show" value="1" <?php checked($show, '1'); ?>>
                <?php esc_html_e('Enabled', 'patlis-menu'); ?>
            </label>
        </td>
    </tr>

    <tr class="form-field">
        <th scope="row"><label><?php esc_html_e('Image', 'patlis-menu'); ?></label></th>
        <td>
            <div id="pmc_image_preview"><?php echo $preview; ?></div>
            <input type="hidden" name="pmc_image_id" id="pmc_image_id" value="<?php echo esc_attr($image_id); ?>">
            <p>
                <button type="button" class="button" id="pmc_image_select"><?php esc_html_e('Select image', 'patlis-menu'); ?></button>
                <button type="button" class="button" id="pmc_image_remove" style="<?php echo $image_id ? '' : 'display:none;'; ?>"><?php esc_html_e('Remove', 'patlis-menu'); ?></button>
            </p>
        </td>
    </tr>

    <tr class="form-field">
        <th scope="row"><label><?php esc_html_e('Category visibility schedule', 'patlis-menu'); ?></label></th>
        <td>
            <table class="widefat striped" style="max-width:720px">
                <thead>
                    <tr>
                        <th style="width:140px;"><?php esc_html_e('Day', 'patlis-menu'); ?></th>
                        <th style="width:200px;"><?php esc_html_e('From', 'patlis-menu'); ?></th>
                        <th style="width:200px;"><?php esc_html_e('To', 'patlis-menu'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php echo patlis_menu_section_schedule_rows((int)$term->term_id); ?>
                </tbody>
            </table>
            <p class="description"><?php esc_html_e('If both fields are empty, the category is visible all day.', 'patlis-menu'); ?></p>
        </td>
    </tr>
    <?php
}

function patlis_menu_section_schedule_rows(int $term_id = 0): string
{
    $days = [
        __('Sunday', 'patlis-menu'),
        __('Monday', 'patlis-menu'),
        __('Tuesday', 'patlis-menu'),
        __('Wednesday', 'patlis-menu'),
        __('Thursday', 'patlis-menu'),
        __('Friday', 'patlis-menu'),
        __('Saturday', 'patlis-menu'),
    ];
    $html = '';

    for ($i = 0; $i <= 6; $i++) {
        $a = $term_id ? (string)get_term_meta($term_id, "pmc_day{$i}a", true) : '';
        $b = $term_id ? (string)get_term_meta($term_id, "pmc_day{$i}b", true) : '';

        $html .= '<tr>';
        $html .= '<td>' . esc_html($days[$i]) . '</td>';
        $html .= '<td><input type="time" name="pmc_day' . $i . 'a" value="' . esc_attr($a) . '" step="60"></td>';
        $html .= '<td><input type="time" name="pmc_day' . $i . 'b" value="' . esc_attr($b) . '" step="60"></td>';
        $html .= '</tr>';
    }

    return $html;
}

/* ------------------------------------------------------------
 * Save term meta
 * ------------------------------------------------------------ */
add_action('created_menu_section', 'patlis_menu_section_save_fields');
add_action('edited_menu_section', 'patlis_menu_section_save_fields');
function patlis_menu_section_save_fields(int $term_id): void
{
    // Nonce (our fields)
    if (!isset($_POST['patlis_menu_section_nonce']) || !wp_verify_nonce((string)$_POST['patlis_menu_section_nonce'], 'patlis_menu_section_meta')) {
        return;
    }

    // Capability: user must be allowed to edit this term
    if (!current_user_can('edit_term', $term_id)) {
        return;
    }

    $show = isset($_POST['pmc_show']) ? '1' : '0';
    update_term_meta($term_id, 'pmc_show', $show);

    $image_id = isset($_POST['pmc_image_id']) ? (int)$_POST['pmc_image_id'] : 0;
    if ($image_id > 0) {
        update_term_meta($term_id, 'pmc_image_id', (string)$image_id);
    } else {
        delete_term_meta($term_id, 'pmc_image_id');
    }

    for ($i = 0; $i <= 6; $i++) {
        $a = isset($_POST["pmc_day{$i}a"]) ? trim((string)$_POST["pmc_day{$i}a"]) : '';
        $b = isset($_POST["pmc_day{$i}b"]) ? trim((string)$_POST["pmc_day{$i}b"]) : '';

        $a = patlis_menu_sanitize_time($a);
        $b = patlis_menu_sanitize_time($b);

        if ($a === '') delete_term_meta($term_id, "pmc_day{$i}a"); else update_term_meta($term_id, "pmc_day{$i}a", $a);
        if ($b === '') delete_term_meta($term_id, "pmc_day{$i}b"); else update_term_meta($term_id, "pmc_day{$i}b", $b);
    }
}

// Auto-assign the last sort position when a new category is created.
add_action('created_menu_section', function (int $term_id): void {
    if (!current_user_can('edit_term', $term_id)) {
        return;
    }

    $all_ids = get_terms([
        'taxonomy'   => 'menu_section',
        'hide_empty' => false,
        'fields'     => 'ids',
        'exclude'    => [$term_id],
    ]);

    $max = 0;
    foreach ((array) $all_ids as $tid) {
        $s = (int) get_term_meta((int) $tid, 'pmc_sort', true);
        if ($s > $max) {
            $max = $s;
        }
    }

    update_term_meta($term_id, 'pmc_sort', (string) ($max + 1));
}, 20);

function patlis_menu_sanitize_time(string $t): string
{
    if ($t === '') return '';
    return preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $t) ? $t : '';
}

/**
 * Computed: is category open now?
 * - pmc_show must be 1
 * - if both empty => open all day
 * - if one empty => open all day (simple rule)
 * - supports overnight ranges (e.g. 18:00 -> 02:00)
 */
function patlis_menu_section_is_open_now(int $term_id): bool
{
    $show = (string)get_term_meta($term_id, 'pmc_show', true);
    if ($show === '0') return false;

    $dt = current_datetime();
    $dayIndex = (int)$dt->format('w'); // 0=Sun..6=Sat
    $nowMin = ((int)$dt->format('H')) * 60 + (int)$dt->format('i');

    $a = (string)get_term_meta($term_id, "pmc_day{$dayIndex}a", true);
    $b = (string)get_term_meta($term_id, "pmc_day{$dayIndex}b", true);

    if ($a === '' && $b === '') return true;
    if ($a === '' || $b === '') return true;

    $aMin = ((int)substr($a, 0, 2)) * 60 + (int)substr($a, 3, 2);
    $bMin = ((int)substr($b, 0, 2)) * 60 + (int)substr($b, 3, 2);

    if ($aMin === $bMin) return true;

    if ($aMin < $bMin) {
        return ($nowMin >= $aMin && $nowMin < $bMin);
    }

    return ($nowMin >= $aMin || $nowMin < $bMin);
}

/* ------------------------------------------------------------
 * Admin list columns (menu_section)
 * ------------------------------------------------------------ */
add_filter('manage_edit-menu_section_columns', function (array $columns): array {
    $new = [];

    foreach ($columns as $key => $label) {
        // Place pmc_sort right before Name.
        if ($key === 'name') {
            $new['pmc_sort'] = '';
        }
        $new[$key] = $label;
    }

    if (!isset($new['pmc_sort'])) {
        $new = ['pmc_sort' => ''] + $new;
    }

    return $new;
});

add_filter('manage_menu_section_custom_column', function ($content, string $column_name, int $term_id) {
    if ($column_name !== 'pmc_sort') return $content;

    return '';
}, 10, 3);

add_filter('manage_edit-menu_section_sortable_columns', function (array $sortable): array {
    $sortable['pmc_sort'] = 'pmc_sort';
    return $sortable;
});

add_action('pre_get_terms', function (WP_Term_Query $query): void {
    if (!is_admin()) return;

    $taxonomy = $query->query_vars['taxonomy'] ?? null;
    if (is_array($taxonomy)) {
        if (!in_array('menu_section', $taxonomy, true)) return;
    } elseif ($taxonomy !== 'menu_section') {
        return;
    }

    $orderby      = (string)($query->query_vars['orderby'] ?? '');
    $user_orderby = isset($_GET['orderby']) ? sanitize_key((string)$_GET['orderby']) : '';
    // Return early only when the user explicitly clicked a different column header.
    if ($user_orderby !== '' && $user_orderby !== 'pmc_sort') {
        return;
    }

    // Rebuild meta_query here because pre_get_terms fires after the initial parse.
    $query->query_vars['meta_key'] = 'pmc_sort';
    $query->query_vars['orderby']  = 'meta_value_num';
    $query->query_vars['meta_type'] = 'NUMERIC';

    if (class_exists('WP_Meta_Query')) {
        $query->meta_query = new WP_Meta_Query();
        $query->meta_query->parse_query_vars($query->query_vars);
    }
});

add_action('wp_ajax_patlis_menu_section_sort', function (): void {
    check_ajax_referer('patlis_menu_section_sort_nonce', 'nonce');

    if (!current_user_can('manage_categories')) {
        wp_send_json_error('Unauthorized', 403);
    }

    $ids = isset($_POST['ids']) ? (array) $_POST['ids'] : [];

    foreach ($ids as $index => $term_id) {
        $term_id = absint($term_id);
        if ($term_id <= 0) {
            continue;
        }
        update_term_meta($term_id, 'pmc_sort', (string) ($index + 1));
    }

    wp_send_json_success();
});
