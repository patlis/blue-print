<?php
/**
 * Plugin Name: Patlis Core
 * Description: Core settings & helpers for Patlis sites.
 * Version: 3.0.0
 * Author: Patlis Ioannis
 * Text Domain: patlis-core
 * Domain Path: /languages
 * Update URI: https://updates.patlis.com/patlis-core/
 */

if (!defined('ABSPATH')) exit;

define('PATLIS_CORE_PATH', plugin_dir_path(__FILE__));
define('PATLIS_CORE_URL',  plugin_dir_url(__FILE__));
define('PATLIS_CORE_VERSION', '3.0.0');

require_once PATLIS_CORE_PATH . 'includes/core.php';
require_once PATLIS_CORE_PATH . 'includes/helpers.php';
require_once PATLIS_CORE_PATH . 'includes/design-colors.php';
require_once PATLIS_CORE_PATH . 'includes/database.php';
require_once PATLIS_CORE_PATH . 'includes/form-handlers.php';
require_once PATLIS_CORE_PATH . 'includes/translations-db.php';
require_once PATLIS_CORE_PATH . 'includes/translations-helpers.php';
require_once PATLIS_CORE_PATH . 'includes/bricks-tags.php';
require_once PATLIS_CORE_PATH . 'includes/languages-visibility.php';
require_once PATLIS_CORE_PATH . 'includes/field-sync.php';
require_once PATLIS_CORE_PATH . 'includes/acf-field-labels.php';
require_once PATLIS_CORE_PATH . 'includes/cpt-labels.php';
require_once PATLIS_CORE_PATH . 'includes/events-gallery.php';
require_once PATLIS_CORE_PATH . 'includes/gallery-manager.php';
require_once PATLIS_CORE_PATH . 'includes/media-ai-status.php';
require_once PATLIS_CORE_PATH . 'includes/sliders/sliders-helpers.php';

// Updater 
if (function_exists('patlis_register_plugin_updater')) {
    patlis_register_plugin_updater(__FILE__, 'patlis-core', PATLIS_CORE_VERSION);
}

if (is_admin()) {
    require_once PATLIS_CORE_PATH . 'includes/admin/menu.php';

    // settings registration must be loaded on EVERY admin request (also options.php)
    require_once PATLIS_CORE_PATH . 'includes/admin/bricks-colors.php';
    require_once PATLIS_CORE_PATH . 'includes/admin/bricks-variables.php';
    require_once PATLIS_CORE_PATH . 'includes/admin/settings.php';

    // admin pages (UI)
    require_once PATLIS_CORE_PATH . 'includes/admin/pages/basic.php';
    require_once PATLIS_CORE_PATH . 'includes/admin/pages/social.php';
    require_once PATLIS_CORE_PATH . 'includes/admin/pages/center-popup.php';
    require_once PATLIS_CORE_PATH . 'includes/admin/pages/notification-bar.php';
    require_once PATLIS_CORE_PATH . 'includes/admin/pages/opening-times.php';
    require_once PATLIS_CORE_PATH . '/includes/admin/pages/translations.php';
    require_once PATLIS_CORE_PATH . '/includes/admin/pages/design-options.php';
    require_once PATLIS_CORE_PATH . '/includes/admin/pages/instance-tools.php';
    require_once PATLIS_CORE_PATH . '/includes/admin/pages/white-label.php';
    require_once PATLIS_CORE_PATH . '/includes/admin/pages/ai-labels.php';
    
    require_once PATLIS_CORE_PATH . '/includes/editor-restrictions.php';
    require_once PATLIS_CORE_PATH . '/includes/admin/admin-columns.php';

    require_once PATLIS_CORE_PATH . '/includes/sliders/sliders-admin.php';
    require_once PATLIS_CORE_PATH . '/includes/sliders/sliders-save.php';

}

add_action('plugins_loaded', function () {
  load_plugin_textdomain('patlis-core', false, dirname(plugin_basename(__FILE__)) . '/languages');
});

register_activation_hook(__FILE__, 'patlis_core_create_or_update_tables');

Patlis_Core::init();