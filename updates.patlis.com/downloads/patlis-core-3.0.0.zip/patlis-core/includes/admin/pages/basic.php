<?php
if (!defined('ABSPATH')) exit;

final class Patlis_Admin_Page_Basic {

  public static function sanitize($input): array {
    $in = is_array($input) ? $input : [];
    $existing = get_option(Patlis_Core::OPTION_BASIC, []);
    $existing = is_array($existing) ? $existing : [];

    $out = [];
    $out['logo_image_id']   = max(0, (int) ($existing['logo_image_id'] ?? 0));
    $out['match_header_colors'] = !empty($existing['match_header_colors']) ? 1 : 0;
    $out['company_name'] = isset($in['company_name']) ? sanitize_text_field($in['company_name']) : '';
    $out['slogan'] = is_array($existing['slogan'] ?? null) ? $existing['slogan'] : [];
    $raw_slogan = isset($in['slogan']) && is_array($in['slogan']) ? $in['slogan'] : [];
    foreach ($raw_slogan as $lang => $text) {
      $lang = sanitize_key((string) $lang);
      if ($lang !== '') $out['slogan'][$lang] = sanitize_text_field((string) $text);
    }
    $out['address']      = isset($in['address']) ? sanitize_text_field($in['address']) : '';
    $out['city']         = isset($in['city']) ? sanitize_text_field($in['city']) : '';
    $out['zip']          = isset($in['zip']) ? sanitize_text_field($in['zip']) : '';
    $out['email']        = isset($in['email']) ? sanitize_email($in['email']) : '';

    $out['phone']        = isset($in['phone']) ? sanitize_text_field($in['phone']) : '';
    $out['phone2']       = isset($in['phone2']) ? sanitize_text_field($in['phone2']) : '';
    $out['mobile']       = isset($in['mobile']) ? sanitize_text_field($in['mobile']) : '';
    $out['whatsapp']     = isset($in['whatsapp']) ? sanitize_text_field($in['whatsapp']) : '';
    $out['cordinates']   = isset($in['cordinates']) ? sanitize_text_field($in['cordinates']) : '';

    $out['timezone']     = isset($in['timezone']) ? sanitize_text_field($in['timezone']) : wp_timezone_string();

    $out['show_contact_form'] = !empty($in['show_contact_form']) ? 1 : 0;
    $out['show_map'] = !empty($in['show_map']) ? 1 : 0;
    $out['contact_form_recipient_email'] = isset($in['contact_form_recipient_email']) ? sanitize_email($in['contact_form_recipient_email']) : '';
    $out['contact_form_email_subject']   = isset($in['contact_form_email_subject']) ? sanitize_text_field($in['contact_form_email_subject']) : '';

    // contact_confirm_subject: multilingual text input array
    $out['contact_confirm_subject'] = [];
    $raw_cs = isset($in['contact_confirm_subject']) && is_array($in['contact_confirm_subject']) ? $in['contact_confirm_subject'] : [];
    foreach ($raw_cs as $lang => $text) {
      $lang = sanitize_key((string) $lang);
      if ($lang !== '') $out['contact_confirm_subject'][$lang] = sanitize_text_field((string) $text);
    }

    // contact_confirm_body: multilingual textarea array
    $out['contact_confirm_body'] = [];
    $raw_cb = isset($in['contact_confirm_body']) && is_array($in['contact_confirm_body']) ? $in['contact_confirm_body'] : [];
    foreach ($raw_cb as $lang => $text) {
      $lang = sanitize_key((string) $lang);
      if ($lang !== '') $out['contact_confirm_body'][$lang] = wp_kses_post((string) $text);
    }

    /* Currency settings */
    $out['currency_symbol']   = isset($in['currency_symbol']) ? sanitize_text_field($in['currency_symbol']) : '';
    $out['decimal_divider']   = isset($in['decimal_divider']) ? sanitize_text_field($in['decimal_divider']) : '';
    $out['currency_position'] = isset($in['currency_position']) ? sanitize_text_field($in['currency_position']) : '';
    
    /* Number format settings */
    $out['decimals'] = isset($in['decimals']) ? (int) $in['decimals'] : 2;
    if ($out['decimals'] < 0) $out['decimals'] = 0;
    if ($out['decimals'] > 2) $out['decimals'] = 2;

    $out['show_legal_notice']   = !empty($in['show_legal_notice'])   ? 1 : 0;
    $out['show_privacy_policy'] = !empty($in['show_privacy_policy']) ? 1 : 0;
    $out['show_terms_of_use']   = !empty($in['show_terms_of_use'])   ? 1 : 0;

    return $out;
  }

  public static function render(): void {
    if (!current_user_can('patlis_manage')) return;

    $opt = get_option(Patlis_Core::OPTION_BASIC, []);
    if (!is_array($opt)) $opt = [];

    $tz_selected = isset($opt['timezone']) && is_string($opt['timezone']) && $opt['timezone'] !== ''
      ? $opt['timezone']
      : wp_timezone_string();

    $divider  = $opt['decimal_divider'] ?? ',';
    $pos      = $opt['currency_position'] ?? 'after';
    $decimals = isset($opt['decimals']) ? (int) $opt['decimals'] : 2;
    $language_slugs = [];
    if (function_exists('patlis_get_effective_language_slugs_for_current_user')) {
      $language_slugs = patlis_get_effective_language_slugs_for_current_user();
    } elseif (function_exists('pll_languages_list')) {
      $language_slugs = pll_languages_list(['fields' => 'slug']);
    }
    if (empty($language_slugs)) $language_slugs = ['default'];
    $slogan_values = is_array($opt['slogan'] ?? null) ? $opt['slogan'] : [];

    // Resolve tab labels early; on some installs late gettext calls inside hidden tab panels return source strings.
    $labels = [
      'basic'                    => __('Basic', 'patlis-core'),
      'contact_form'             => __('Contact form', 'patlis-core'),
      'currency'                 => __('Currency', 'patlis-core'),
      'display_contact_form'     => __('Display the contact form', 'patlis-core'),
      'display_map'              => __('Display the map', 'patlis-core'),
      'recipient_email'          => __('Recipient email', 'patlis-core'),
      'email_subject'            => __('Email subject', 'patlis-core'),
      'currency_symbol'          => __('Currency symbol', 'patlis-core'),
      'decimal_divider'          => __('Decimal divider', 'patlis-core'),
      'currency_position'        => __('Currency position', 'patlis-core'),
      'after_the_amount'         => __('After the amount', 'patlis-core'),
      'before_the_amount'        => __('Before the amount', 'patlis-core'),
      'decimals'                 => __('Decimals', 'patlis-core'),
      'legal_links'              => __('Legal links', 'patlis-core'),
      'show_legal_notice'        => __('Show legal notice page', 'patlis-core'),
      'show_privacy_policy'      => __('Show privacy policy page', 'patlis-core'),
      'show_terms_of_use'        => __('Show terms of use page', 'patlis-core'),
      'confirmation_email'       => __('Confirmation email to client', 'patlis-core'),
      'confirmation_subject'     => __('Subject (%s)', 'patlis-core'),
      'confirmation_body'        => __('Body (%s)', 'patlis-core'),
      'save'                     => __('Save', 'patlis-core'),
    ];

    ?>
    <div class="wrap">
      <h1><?php esc_html_e('Basic settings', 'patlis-core'); ?></h1>

        <?php if (!empty($_GET['patlis_saved'])): ?>
            <div class="notice notice-success is-dismissible"><p>Saved.</p></div>
        <?php endif; ?>


      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
          <input type="hidden" name="action" value="patlis_save_basic">
          <?php wp_nonce_field('patlis_save_basic'); ?>

        <style>
          .patlis-basic-tabs-panels {
            margin-top: 18px;
          }
          .patlis-basic-tab-panel {
            display: none;
          }
          .patlis-basic-tab-panel.is-active {
            display: block;
          }
        </style>

        <nav class="nav-tab-wrapper">
          <a href="#" class="nav-tab nav-tab-active" data-tab="basic"><?php echo esc_html($labels['basic']); ?></a>
          <a href="#" class="nav-tab" data-tab="contact"><?php echo esc_html($labels['contact_form']); ?></a>
          <a href="#" class="nav-tab" data-tab="currency"><?php echo esc_html($labels['currency']); ?></a>
          <a href="#" class="nav-tab" data-tab="legal"><?php echo esc_html($labels['legal_links']); ?></a>
        </nav>

        <div class="patlis-basic-tabs-panels">
          <div class="patlis-basic-tab-panel is-active" data-panel="basic">
            <table class="form-table" role="presentation">

              <tr>
                <th scope="row"><label for="patlis_company_name"><?php esc_html_e('Company name', 'patlis-core'); ?></label></th>
                <td>
                  <input id="patlis_company_name" type="text" class="regular-text"
                    name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[company_name]"
                    value="<?php echo esc_attr($opt['company_name'] ?? ''); ?>">
                </td>
              </tr>


              <tr>
                <th scope="row"><label for="patlis_address"><?php esc_html_e('Address', 'patlis-core'); ?></label></th>
                <td>
                  <input id="patlis_address" type="text" class="regular-text"
                    name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[address]"
                    value="<?php echo esc_attr($opt['address'] ?? ''); ?>">
                </td>
              </tr>

              <tr>
                <th scope="row"><label for="patlis_city"><?php esc_html_e('City', 'patlis-core'); ?></label></th>
                <td>
                  <input id="patlis_city" type="text" class="regular-text"
                    name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[city]"
                    value="<?php echo esc_attr($opt['city'] ?? ''); ?>">
                </td>
              </tr>

              <tr>
                <th scope="row"><label for="patlis_zip"><?php esc_html_e('Zip code', 'patlis-core'); ?></label></th>
                <td>
                  <input id="patlis_zip" type="text" class="regular-text"
                    name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[zip]"
                    value="<?php echo esc_attr($opt['zip'] ?? ''); ?>">
                </td>
              </tr>

              <tr>
                <th scope="row"><label for="patlis_email">E-mail</label></th>
                <td>
                  <input id="patlis_email" type="email" class="regular-text"
                    name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[email]"
                    value="<?php echo esc_attr($opt['email'] ?? ''); ?>">
                </td>
              </tr>

              <tr>
                <th scope="row"><label for="patlis_phone"><?php esc_html_e('Phone', 'patlis-core'); ?></label></th>
                <td>
                  <input id="patlis_phone" type="text" class="regular-text"
                    name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[phone]"
                    value="<?php echo esc_attr($opt['phone'] ?? ''); ?>">
                </td>
              </tr>

              <tr>
                <th scope="row"><label for="patlis_phone2"><?php esc_html_e('Phone-2', 'patlis-core'); ?></label></th>
                <td>
                  <input id="patlis_phone2" type="text" class="regular-text"
                    name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[phone2]"
                    value="<?php echo esc_attr($opt['phone2'] ?? ''); ?>">
                </td>
              </tr>

              <tr>
                <th scope="row"><label for="patlis_mobile"><?php esc_html_e('Mobile phone', 'patlis-core'); ?></label></th>
                <td>
                  <input id="patlis_mobile" type="text" class="regular-text"
                    name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[mobile]"
                    value="<?php echo esc_attr($opt['mobile'] ?? ''); ?>">
                </td>
              </tr>

              <tr>
                <th scope="row"><label for="patlis_whatsapp">WhatsApp</label></th>
                <td>
                  <input id="patlis_whatsapp" type="text" class="regular-text"
                    name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[whatsapp]"
                    value="<?php echo esc_attr($opt['whatsapp'] ?? ''); ?>">
                </td>
              </tr>

              <tr>
                <th scope="row"><label for="patlis_cordinates"><?php esc_html_e('Coordinates', 'patlis-core'); ?></label></th>
                <td>
                  <input id="patlis_cordinates" type="text" class="regular-text"
                    name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[cordinates]"
                    value="<?php echo esc_attr($opt['cordinates'] ?? ''); ?>">
                </td>
              </tr>

              <tr>
                <th scope="row"><label for="patlis_timezone"><?php esc_html_e('Time zone', 'patlis-core'); ?></label></th>
                <td>
                  <select id="patlis_timezone" name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[timezone]">
                    <?php echo wp_timezone_choice($tz_selected); ?>
                  </select>
                </td>
              </tr>

              <?php foreach ($language_slugs as $language_slug): $language_slug = sanitize_key((string) $language_slug); ?>
              <tr>
                <th scope="row"><label for="patlis_slogan_<?php echo esc_attr($language_slug); ?>"><?php echo esc_html(sprintf(__('Slogan (%s)', 'patlis-core'), strtoupper($language_slug))); ?></label></th>
                <td>
                  <input id="patlis_slogan_<?php echo esc_attr($language_slug); ?>" type="text" class="regular-text"
                    name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[slogan][<?php echo esc_attr($language_slug); ?>]"
                    value="<?php echo esc_attr($slogan_values[$language_slug] ?? ''); ?>">
                </td>
              </tr>
              <?php endforeach; ?>

            </table>
          </div>

          <div class="patlis-basic-tab-panel" data-panel="contact">
            <table class="form-table" role="presentation">
              <tr>
                <th scope="row"><?php echo esc_html($labels['display_contact_form']); ?></th>
                <td>
                  <label>
                    <input type="checkbox"
                      name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[show_contact_form]"
                      value="1" <?php checked(!empty($opt['show_contact_form'])); ?>>
                  </label>
                </td>
              </tr>

              <tr>
                <th scope="row"><label for="patlis_show_map"><?php echo esc_html($labels['display_map']); ?></label></th>
                <td>
                  <input id="patlis_show_map" type="checkbox"
                    name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[show_map]"
                    value="1" <?php checked(!array_key_exists('show_map', $opt) || !empty($opt['show_map'])); ?>>
                </td>
              </tr>

              <tr>
                <th scope="row"><label for="patlis_contact_form_recipient_email"><?php echo esc_html($labels['recipient_email']); ?></label></th>
                <td>
                  <input id="patlis_contact_form_recipient_email" type="email" class="regular-text"
                    name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[contact_form_recipient_email]"
                    value="<?php echo esc_attr($opt['contact_form_recipient_email'] ?? ''); ?>">
                </td>
              </tr>

              <tr>
                <th scope="row"><label for="patlis_contact_form_email_subject"><?php echo esc_html($labels['email_subject']); ?></label></th>
                <td>
                  <input id="patlis_contact_form_email_subject" type="text" class="large-text"
                    name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[contact_form_email_subject]"
                    value="<?php echo esc_attr($opt['contact_form_email_subject'] ?? ''); ?>">
                </td>
              </tr>

              <?php
              $cc_subject = is_array($opt['contact_confirm_subject'] ?? null) ? $opt['contact_confirm_subject'] : [];
              $cc_body    = is_array($opt['contact_confirm_body']    ?? null) ? $opt['contact_confirm_body']    : [];
              ?>
              <tr><td colspan="2"><h3 style="text-align: center;"><?php echo esc_html($labels['confirmation_email']); ?></h3></td></tr>
              <?php foreach ($language_slugs as $ls): $ls = (string)$ls; ?>
              <tr>
                <th scope="row"><?php echo esc_html(sprintf($labels['confirmation_subject'], strtoupper($ls))); ?></th>
                <td>
                  <input type="text" class="large-text"
                    name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[contact_confirm_subject][<?php echo esc_attr($ls); ?>]"
                    value="<?php echo esc_attr($cc_subject[$ls] ?? ''); ?>">
                </td>
              </tr>
              <tr>
                <th scope="row"><?php echo esc_html(sprintf($labels['confirmation_body'], strtoupper($ls))); ?></th>
                <td>
                  <textarea class="large-text" rows="6"
                    name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[contact_confirm_body][<?php echo esc_attr($ls); ?>]"><?php echo wp_kses_post($cc_body[$ls] ?? ''); ?></textarea>
                </td>
              </tr>
              <?php endforeach; ?>
            </table>
          </div>

          <div class="patlis-basic-tab-panel" data-panel="currency">
            <table class="form-table" role="presentation">
              <tr>
                <th scope="row"><label for="patlis_currency_symbol"><?php echo esc_html($labels['currency_symbol']); ?></label></th>
                <td>
                  <input id="patlis_currency_symbol" type="text" class="regular-text"
                    name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[currency_symbol]"
                    value="<?php echo esc_attr($opt['currency_symbol'] ?? ''); ?>">
                </td>
              </tr>

              <tr>
                <th scope="row"><label for="patlis_decimal_divider"><?php echo esc_html($labels['decimal_divider']); ?></label></th>
                <td>
                  <select id="patlis_decimal_divider"
                    name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[decimal_divider]">
                    <option value="," <?php selected($divider, ','); ?>>,</option>
                    <option value="." <?php selected($divider, '.'); ?>>.</option>
                    <option value="٫" <?php selected($divider, '٫'); ?>>٫</option>
                    <option value="'" <?php selected($divider, "'"); ?>>'</option>
                  </select>
                </td>
              </tr>

              <tr>
                <th scope="row"><label for="patlis_currency_position"><?php echo esc_html($labels['currency_position']); ?></label></th>
                <td>
                  <select id="patlis_currency_position"
                    name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[currency_position]">
                    <option value="after" <?php selected($pos, 'after'); ?>><?php echo esc_html($labels['after_the_amount']); ?></option>
                    <option value="before" <?php selected($pos, 'before'); ?>><?php echo esc_html($labels['before_the_amount']); ?></option>
                  </select>
                </td>
              </tr>

              <tr>
                <th scope="row"><label for="patlis_decimals"><?php echo esc_html($labels['decimals']); ?></label></th>
                <td>
                  <select id="patlis_decimals"
                    name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[decimals]">
                    <option value="0" <?php selected($decimals, 0); ?>>0</option>
                    <option value="1" <?php selected($decimals, 1); ?>>1</option>
                    <option value="2" <?php selected($decimals, 2); ?>>2</option>
                  </select>
                </td>
              </tr>
            </table>
          </div>

          <div class="patlis-basic-tab-panel" data-panel="legal">
            <table class="form-table" role="presentation">
              <tr>
                <th scope="row"><?php echo esc_html($labels['show_legal_notice']); ?></th>
                <td>
                  <label>
                    <input type="checkbox"
                      name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[show_legal_notice]"
                      value="1" <?php checked(!array_key_exists('show_legal_notice', $opt) || !empty($opt['show_legal_notice'])); ?>
                  </label>
                </td>
              </tr>

              <tr>
                <th scope="row"><?php echo esc_html($labels['show_privacy_policy']); ?></th>
                <td>
                  <label>
                    <input type="checkbox"
                      name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[show_privacy_policy]"
                      value="1" <?php checked(!array_key_exists('show_privacy_policy', $opt) || !empty($opt['show_privacy_policy'])); ?>
                  </label>
                </td>
              </tr>

              <tr>
                <th scope="row"><?php echo esc_html($labels['show_terms_of_use']); ?></th>
                <td>
                  <label>
                    <input type="checkbox"
                      name="<?php echo esc_attr(Patlis_Core::OPTION_BASIC); ?>[show_terms_of_use]"
                      value="1" <?php checked(!empty($opt['show_terms_of_use'])); ?>>
                  </label>
                </td>
              </tr>
            </table>
          </div>
        </div>

        <script>
          document.addEventListener('DOMContentLoaded', function () {
            var tabs = document.querySelectorAll('.nav-tab-wrapper .nav-tab[data-tab]');
            var panels = document.querySelectorAll('.patlis-basic-tab-panel[data-panel]');
            tabs.forEach(function (tab) {
              tab.addEventListener('click', function (event) {
                event.preventDefault();

                var target = tab.getAttribute('data-tab');

                tabs.forEach(function (item) {
                  item.classList.remove('nav-tab-active');
                });

                panels.forEach(function (panel) {
                  panel.classList.toggle('is-active', panel.getAttribute('data-panel') === target);
                });

                tab.classList.add('nav-tab-active');
              });
            });

          });
        </script>

        <?php submit_button($labels['save']); ?>
      </form>
    </div>
    <?php
  }
}